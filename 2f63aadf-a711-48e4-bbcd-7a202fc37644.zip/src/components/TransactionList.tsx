import React, { useState } from 'react';
import { SearchIcon, FilterIcon, CalendarIcon, ChevronDownIcon } from 'lucide-react';
export const TransactionList = () => {
  const [filterOpen, setFilterOpen] = useState(false);
  // Dummy data for transactions
  const transactions = [{
    id: 1,
    description: 'Grocery Shopping',
    category: 'Groceries',
    date: 'Jul 18, 2023',
    amount: '₹85.25',
    type: 'expense'
  }, {
    id: 2,
    description: 'Monthly Salary',
    category: 'Income',
    date: 'Jul 17, 2023',
    amount: '₹3,250.00',
    type: 'income'
  }, {
    id: 3,
    description: 'Restaurant Dinner',
    category: 'Dining',
    date: 'Jul 15, 2023',
    amount: '₹64.80',
    type: 'expense'
  }, {
    id: 4,
    description: 'Electricity Bill',
    category: 'Utilities',
    date: 'Jul 14, 2023',
    amount: '₹120.50',
    type: 'expense'
  }, {
    id: 5,
    description: 'Freelance Project',
    category: 'Income',
    date: 'Jul 10, 2023',
    amount: '₹850.00',
    type: 'income'
  }, {
    id: 6,
    description: 'Gym Membership',
    category: 'Health',
    date: 'Jul 8, 2023',
    amount: '₹45.00',
    type: 'expense'
  }, {
    id: 7,
    description: 'Online Course',
    category: 'Education',
    date: 'Jul 5, 2023',
    amount: '₹199.99',
    type: 'expense'
  }, {
    id: 8,
    description: 'Movie Tickets',
    category: 'Entertainment',
    date: 'Jul 3, 2023',
    amount: '₹32.50',
    type: 'expense'
  }, {
    id: 9,
    description: 'Gas',
    category: 'Transportation',
    date: 'Jul 2, 2023',
    amount: '₹48.75',
    type: 'expense'
  }, {
    id: 10,
    description: 'Dividend Payment',
    category: 'Income',
    date: 'Jul 1, 2023',
    amount: '₹125.30',
    type: 'income'
  }];
  return <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">Transactions</h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors">
          + Add New
        </button>
      </div>
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
          <div className="relative flex-1">
            <SearchIcon size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Search transactions..." className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent" />
          </div>
          <div className="flex gap-3">
            <button onClick={() => setFilterOpen(!filterOpen)} className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <FilterIcon size={18} />
              <span>Filter</span>
              <ChevronDownIcon size={16} className={`transition-transform ${filterOpen ? 'rotate-180' : ''}`} />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <CalendarIcon size={18} />
              <span>Date Range</span>
            </button>
          </div>
        </div>
        {filterOpen && <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <select className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <option value="">All Categories</option>
                <option value="groceries">Groceries</option>
                <option value="dining">Dining</option>
                <option value="utilities">Utilities</option>
                <option value="income">Income</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount Range
              </label>
              <div className="flex items-center gap-2">
                <input type="number" placeholder="Min" className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                <span>-</span>
                <input type="number" placeholder="Max" className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Type
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <span>Expense</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <span>Income</span>
                </label>
              </div>
            </div>
          </div>}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-sm text-gray-500 border-b">
                <th className="pb-3 font-medium">Description</th>
                <th className="pb-3 font-medium">Category</th>
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium text-right">Amount</th>
                <th className="pb-3 font-medium"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {transactions.map(transaction => <tr key={transaction.id} className="text-sm">
                  <td className="py-4 font-medium text-gray-800">
                    {transaction.description}
                  </td>
                  <td className="py-4">
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      {transaction.category}
                    </span>
                  </td>
                  <td className="py-4 text-gray-500">{transaction.date}</td>
                  <td className={`py-4 text-right font-medium ${transaction.type === 'income' ? 'text-emerald-600' : 'text-gray-800'}`}>
                    {transaction.type === 'income' ? '+' : ''}
                    {transaction.amount}
                  </td>
                  <td className="py-4 text-right">
                    <button className="text-gray-400 hover:text-gray-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z" />
                      </svg>
                    </button>
                  </td>
                </tr>)}
            </tbody>
          </table>
        </div>
        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Showing 1 to 10 of 120 transactions
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1 border border-gray-300 rounded-md text-sm disabled:opacity-50">
              Previous
            </button>
            <button className="px-3 py-1 bg-indigo-600 text-white rounded-md text-sm hover:bg-indigo-700">
              1
            </button>
            <button className="px-3 py-1 border border-gray-300 rounded-md text-sm hover:bg-gray-50">
              2
            </button>
            <button className="px-3 py-1 border border-gray-300 rounded-md text-sm hover:bg-gray-50">
              3
            </button>
            <button className="px-3 py-1 border border-gray-300 rounded-md text-sm hover:bg-gray-50">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>;
};