import React, { useState } from 'react';
import { LayoutDashboardIcon, ListIcon, PlusCircleIcon, PieChartIcon, MenuIcon, XIcon, WalletIcon } from 'lucide-react';
interface MobileSidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
}
export const MobileSidebar = ({
  activeView,
  setActiveView
}: MobileSidebarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuItems = [{
    id: 'dashboard',
    label: 'Dashboard',
    icon: <LayoutDashboardIcon size={20} />
  }, {
    id: 'transactions',
    label: 'Transactions',
    icon: <ListIcon size={20} />
  }, {
    id: 'add',
    label: 'Add Expense',
    icon: <PlusCircleIcon size={20} />
  }, {
    id: 'charts',
    label: 'Analytics',
    icon: <PieChartIcon size={20} />
  }];
  const handleNavigation = (view: string) => {
    setActiveView(view);
    setIsOpen(false);
  };
  return <div className="md:hidden">
      <div className="flex items-center justify-between p-4 bg-indigo-900 text-white">
        <div className="flex items-center gap-2">
          <WalletIcon size={20} />
          <h1 className="font-bold">ExpenseTracker</h1>
        </div>
        <button onClick={() => setIsOpen(!isOpen)} className="p-1">
          {isOpen ? <XIcon size={24} /> : <MenuIcon size={24} />}
        </button>
      </div>
      {isOpen && <div className="absolute top-16 left-0 right-0 bg-indigo-900 text-white z-50 shadow-lg">
          <ul>
            {menuItems.map(item => <li key={item.id}>
                <button onClick={() => handleNavigation(item.id)} className={`flex items-center gap-3 px-5 py-4 w-full text-left hover:bg-indigo-800 transition-colors ${activeView === item.id ? 'bg-indigo-800 border-l-4 border-white' : ''}`}>
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              </li>)}
          </ul>
        </div>}
    </div>;
};