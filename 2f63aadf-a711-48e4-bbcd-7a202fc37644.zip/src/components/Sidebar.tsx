import React from 'react';
import { LayoutDashboardIcon, ListIcon, PlusCircleIcon, PieChartIcon, LogOutIcon, WalletIcon } from 'lucide-react';
interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
}
export const Sidebar = ({
  activeView,
  setActiveView
}: SidebarProps) => {
  const menuItems = [{
    id: 'dashboard',
    label: 'Dashboard',
    icon: <LayoutDashboardIcon size={20} />
  }, {
    id: 'transactions',
    label: 'Transactions',
    icon: <ListIcon size={20} />
  }, {
    id: 'add',
    label: 'Add Expense',
    icon: <PlusCircleIcon size={20} />
  }, {
    id: 'charts',
    label: 'Analytics',
    icon: <PieChartIcon size={20} />
  }];
  return <div className="w-64 bg-indigo-900 text-white min-h-screen flex flex-col shadow-lg hidden md:block">
      <div className="p-5 border-b border-indigo-800">
        <div className="flex items-center gap-3">
          <WalletIcon size={24} />
          <h1 className="text-xl font-bold">ExpenseTracker</h1>
        </div>
      </div>
      <nav className="flex-1 pt-5">
        <ul>
          {menuItems.map(item => <li key={item.id}>
              <button onClick={() => setActiveView(item.id)} className={`flex items-center gap-3 px-5 py-3 w-full text-left hover:bg-indigo-800 transition-colors ${activeView === item.id ? 'bg-indigo-800 border-l-4 border-white' : ''}`}>
                {item.icon}
                <span>{item.label}</span>
              </button>
            </li>)}
        </ul>
      </nav>
      <div className="p-5 border-t border-indigo-800">
        <button className="flex items-center gap-3 text-indigo-200 hover:text-white transition-colors">
          <LogOutIcon size={20} />
          <span>Logout</span>
        </button>
      </div>
    </div>;
};