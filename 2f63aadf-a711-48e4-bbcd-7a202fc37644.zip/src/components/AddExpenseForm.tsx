import React from 'react';
import { DollarSignIcon, CalendarIcon, TagIcon, MessageSquareTextIcon, ImageIcon, PaperclipIcon } from 'lucide-react';
export const AddExpenseForm = () => {
  const categories = [{
    id: 'groceries',
    name: 'Groceries'
  }, {
    id: 'dining',
    name: 'Dining'
  }, {
    id: 'transportation',
    name: 'Transportation'
  }, {
    id: 'utilities',
    name: 'Utilities'
  }, {
    id: 'entertainment',
    name: 'Entertainment'
  }, {
    id: 'health',
    name: 'Health'
  }, {
    id: 'education',
    name: 'Education'
  }, {
    id: 'shopping',
    name: 'Shopping'
  }, {
    id: 'travel',
    name: 'Travel'
  }, {
    id: 'other',
    name: 'Other'
  }];
  return <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">
          Add New Transaction
        </h1>
        <div className="flex gap-2">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
            Save Transaction
          </button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Transaction Type
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="transactionType" value="expense" defaultChecked className="text-indigo-600 focus:ring-indigo-500" />
                  <span>Expense</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="transactionType" value="income" className="text-indigo-600 focus:ring-indigo-500" />
                  <span>Income</span>
                </label>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                  ₹
                </span>
                <input type="number" placeholder="0.00" className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date
              </label>
              <div className="relative">
                <CalendarIcon size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input type="date" defaultValue={new Date().toISOString().split('T')[0]} className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <div className="relative">
                <TagIcon size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <select className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                  <option value="">Select a category</option>
                  {categories.map(category => <option key={category.id} value={category.id}>
                      {category.name}
                    </option>)}
                </select>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <div className="relative">
                <MessageSquareTextIcon size={18} className="absolute left-3 top-3 text-gray-400" />
                <textarea placeholder="Add a description..." rows={4} className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"></textarea>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Receipt Image (optional)
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <ImageIcon size={24} className="mx-auto text-gray-400 mb-2" />
                <div className="text-sm text-gray-500">
                  Drag and drop an image here or
                  <button className="text-indigo-600 hover:text-indigo-800 ml-1">
                    browse
                  </button>
                </div>
                <input type="file" className="hidden" />
              </div>
            </div>
          </div>
        </div>
        <div className="mt-6 pt-6 border-t">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PaperclipIcon size={18} className="text-gray-400" />
              <span className="text-sm text-gray-500">Add attachment</span>
            </div>
            <div>
              <button className="mr-3 text-gray-500 hover:text-gray-700">
                Clear Form
              </button>
              <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                Save Transaction
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-6 bg-indigo-50 border border-indigo-100 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-indigo-100 rounded-full text-indigo-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h3 className="font-medium text-indigo-800">Pro Tip</h3>
            <p className="text-sm text-indigo-600">
              You can quickly add transactions by taking a photo of your
              receipt. Our system will automatically extract the amount, date,
              and merchant information.
            </p>
          </div>
        </div>
      </div>
    </div>;
};