import React, { useState } from 'react';
import { BarChartIcon, PieChartIcon, TrendingUpIcon, CalendarIcon, ChevronDownIcon, DownloadIcon, RefreshCwIcon } from 'lucide-react';
export const ExpenseChart = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [timeRange, setTimeRange] = useState('This Month');
  const [timeRangeOpen, setTimeRangeOpen] = useState(false);
  const timeRangeOptions = ['Today', 'This Week', 'This Month', 'Last Month', 'Last 3 Months', 'This Year', 'Custom Range'];
  return <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-800">Analytics</h1>
        <div className="flex items-center gap-3">
          <div className="relative">
            <button onClick={() => setTimeRangeOpen(!timeRangeOpen)} className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <CalendarIcon size={18} />
              <span>{timeRange}</span>
              <ChevronDownIcon size={16} className={`transition-transform ${timeRangeOpen ? 'rotate-180' : ''}`} />
            </button>
            {timeRangeOpen && <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-10 w-48">
                {timeRangeOptions.map(option => <button key={option} onClick={() => {
              setTimeRange(option);
              setTimeRangeOpen(false);
            }} className={`block w-full text-left px-4 py-2 hover:bg-gray-50 ${option === timeRange ? 'bg-indigo-50 text-indigo-600' : ''}`}>
                    {option}
                  </button>)}
              </div>}
          </div>
          <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <DownloadIcon size={18} />
          </button>
          <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <RefreshCwIcon size={18} />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <SummaryCard title="Total Expenses" value="₹2,854.90" change="-8.3%" changeType="decrease" />
        <SummaryCard title="Average Daily Spend" value="₹92.09" change="+4.6%" changeType="increase" />
        <SummaryCard title="Highest Spending Category" value="Housing" subValue="₹1,200.00" change="42%" changeType="neutral" />
      </div>
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="flex border-b">
          <button onClick={() => setActiveTab('overview')} className={`px-6 py-4 font-medium text-sm flex items-center gap-2 ${activeTab === 'overview' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-600 hover:text-gray-800'}`}>
            <BarChartIcon size={18} />
            Spending Overview
          </button>
          <button onClick={() => setActiveTab('categories')} className={`px-6 py-4 font-medium text-sm flex items-center gap-2 ${activeTab === 'categories' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-600 hover:text-gray-800'}`}>
            <PieChartIcon size={18} />
            Categories
          </button>
          <button onClick={() => setActiveTab('trends')} className={`px-6 py-4 font-medium text-sm flex items-center gap-2 ${activeTab === 'trends' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-600 hover:text-gray-800'}`}>
            <TrendingUpIcon size={18} />
            Trends
          </button>
        </div>
        <div className="p-6">
          {activeTab === 'overview' && <div>
              <h3 className="text-lg font-medium text-gray-800 mb-6">
                Monthly Spending Overview
              </h3>
              <div className="h-80 flex items-center justify-center text-gray-400">
                Bar chart visualization would appear here
              </div>
            </div>}
          {activeTab === 'categories' && <div>
              <h3 className="text-lg font-medium text-gray-800 mb-6">
                Spending by Category
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="h-80 flex items-center justify-center text-gray-400">
                  Pie chart visualization would appear here
                </div>
                <div>
                  <div className="space-y-4">
                    <CategoryBreakdown name="Housing" amount="₹1,200.00" percentage={42} color="bg-blue-500" />
                    <CategoryBreakdown name="Groceries" amount="₹485.25" percentage={17} color="bg-emerald-500" />
                    <CategoryBreakdown name="Dining" amount="₹320.80" percentage={11} color="bg-amber-500" />
                    <CategoryBreakdown name="Transportation" amount="₹250.45" percentage={9} color="bg-indigo-500" />
                    <CategoryBreakdown name="Utilities" amount="₹198.50" percentage={7} color="bg-rose-500" />
                    <CategoryBreakdown name="Others" amount="₹399.90" percentage={14} color="bg-gray-500" />
                  </div>
                </div>
              </div>
            </div>}
          {activeTab === 'trends' && <div>
              <h3 className="text-lg font-medium text-gray-800 mb-6">
                Spending Trends
              </h3>
              <div className="h-80 flex items-center justify-center text-gray-400">
                Line chart visualization would appear here
              </div>
            </div>}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-medium text-gray-800 mb-4">
            Top Spending Categories
          </h3>
          <div className="space-y-4">
            {['Housing', 'Groceries', 'Dining', 'Transportation', 'Utilities'].map((category, index) => <div key={category} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-lg font-medium text-gray-500 w-5 text-center">
                    {index + 1}
                  </div>
                  <span className="font-medium text-gray-800">{category}</span>
                </div>
                <span className="font-medium">
                  ₹{(1200 - index * 200).toFixed(2)}
                </span>
              </div>)}
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-medium text-gray-800 mb-4">
            Budget Status
          </h3>
          <div className="space-y-6">
            <BudgetItem category="Overall" spent={2854.9} budget={3500} color="bg-indigo-500" />
            <BudgetItem category="Groceries" spent={485.25} budget={500} color="bg-emerald-500" />
            <BudgetItem category="Dining" spent={320.8} budget={300} color="bg-amber-500" overBudget />
          </div>
        </div>
      </div>
    </div>;
};
interface SummaryCardProps {
  title: string;
  value: string;
  subValue?: string;
  change: string;
  changeType: 'increase' | 'decrease' | 'neutral';
}
const SummaryCard = ({
  title,
  value,
  subValue,
  change,
  changeType
}: SummaryCardProps) => {
  return <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-gray-500 text-sm mb-2">{title}</h3>
      <div className="flex flex-col">
        <span className="text-2xl font-bold text-gray-800">{value}</span>
        {subValue && <span className="text-gray-500 text-sm">{subValue}</span>}
      </div>
      <div className="mt-2 flex items-center text-sm">
        <span className={`font-medium ${changeType === 'increase' ? 'text-emerald-600' : changeType === 'decrease' ? 'text-red-600' : 'text-gray-500'}`}>
          {change}
        </span>
        {changeType !== 'neutral' && <span className="ml-1 text-gray-500">
            {changeType === 'increase' ? 'increase' : 'decrease'} from last
            period
          </span>}
      </div>
    </div>;
};
interface CategoryBreakdownProps {
  name: string;
  amount: string;
  percentage: number;
  color: string;
}
const CategoryBreakdown = ({
  name,
  amount,
  percentage,
  color
}: CategoryBreakdownProps) => {
  return <div>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${color}`}></div>
          <span className="font-medium text-gray-700">{name}</span>
        </div>
        <div className="text-right">
          <div className="font-medium text-gray-900">{amount}</div>
          <div className="text-xs text-gray-500">{percentage}%</div>
        </div>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-1.5">
        <div className={`${color} h-1.5 rounded-full`} style={{
        width: `${percentage}%`
      }}></div>
      </div>
    </div>;
};
interface BudgetItemProps {
  category: string;
  spent: number;
  budget: number;
  color: string;
  overBudget?: boolean;
}
const BudgetItem = ({
  category,
  spent,
  budget,
  color,
  overBudget
}: BudgetItemProps) => {
  const percentage = Math.min(100, spent / budget * 100);
  return <div>
      <div className="flex items-center justify-between mb-1">
        <span className="font-medium text-gray-700">{category}</span>
        <div className="text-right">
          <span className={`font-medium ${overBudget ? 'text-red-600' : 'text-gray-900'}`}>
            ₹{spent.toFixed(2)}
          </span>
          <span className="text-gray-500"> / ₹{budget.toFixed(2)}</span>
        </div>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div className={`${overBudget ? 'bg-red-500' : color} h-2 rounded-full`} style={{
        width: `${percentage}%`
      }}></div>
      </div>
      <div className="mt-1 flex justify-between text-xs text-gray-500">
        <span>{percentage.toFixed(0)}% used</span>
        <span>₹{(budget - spent).toFixed(2)} remaining</span>
      </div>
    </div>;
};