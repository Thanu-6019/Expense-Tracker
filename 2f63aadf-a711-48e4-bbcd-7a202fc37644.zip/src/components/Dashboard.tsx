import React from 'react';
import { TrendingUpIcon, TrendingDownIcon, DollarSignIcon, CalendarIcon, ShoppingBagIcon, CoffeeIcon, HomeIcon, CarIcon } from 'lucide-react';
export const Dashboard = () => {
  const currentMonth = new Intl.DateTimeFormat('en-US', {
    month: 'long'
  }).format(new Date());
  return <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <div className="flex items-center gap-2 text-sm bg-white p-2 rounded-lg shadow">
          <CalendarIcon size={16} className="text-indigo-600" />
          <span>{currentMonth} Overview</span>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Spent" value="₹2,854.90" trend="-8.3%" trendDirection="down" icon={<DollarSignIcon className="text-white" size={20} />} color="bg-indigo-600" />
        <StatCard title="Income" value="₹6,500.00" trend="+2.1%" trendDirection="up" icon={<DollarSignIcon className="text-white" size={20} />} color="bg-emerald-600" />
        <StatCard title="Savings" value="₹3,645.10" trend="+12.5%" trendDirection="up" icon={<DollarSignIcon className="text-white" size={20} />} color="bg-blue-600" />
        <StatCard title="Pending" value="₹350.00" trend="0%" trendDirection="neutral" icon={<DollarSignIcon className="text-white" size={20} />} color="bg-amber-600" />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 col-span-2">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            Monthly Spending Trend
          </h2>
          <div className="h-64 flex items-center justify-center text-gray-400">
            Chart visualization would appear here
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              Top Categories
            </h2>
            <button className="text-sm text-indigo-600 hover:text-indigo-800">
              See All
            </button>
          </div>
          <div className="space-y-4">
            <CategoryItem name="Groceries" amount="₹485.25" percentage={35} color="bg-emerald-500" icon={<ShoppingBagIcon size={18} />} />
            <CategoryItem name="Dining" amount="₹320.80" percentage={24} color="bg-amber-500" icon={<CoffeeIcon size={18} />} />
            <CategoryItem name="Housing" amount="₹1,200.00" percentage={20} color="bg-blue-500" icon={<HomeIcon size={18} />} />
            <CategoryItem name="Transportation" amount="₹250.45" percentage={15} color="bg-indigo-500" icon={<CarIcon size={18} />} />
          </div>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">
            Recent Transactions
          </h2>
          <button className="text-sm text-indigo-600 hover:text-indigo-800">
            View All
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-sm text-gray-500 border-b">
                <th className="pb-3 font-medium">Description</th>
                <th className="pb-3 font-medium">Category</th>
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              <TransactionRow description="Grocery Shopping" category="Groceries" date="Today" amount="₹85.25" type="expense" />
              <TransactionRow description="Monthly Salary" category="Income" date="Yesterday" amount="₹3,250.00" type="income" />
              <TransactionRow description="Restaurant Dinner" category="Dining" date="Jul 15, 2023" amount="₹64.80" type="expense" />
              <TransactionRow description="Electricity Bill" category="Utilities" date="Jul 14, 2023" amount="₹120.50" type="expense" />
              <TransactionRow description="Freelance Project" category="Income" date="Jul 10, 2023" amount="₹850.00" type="income" />
            </tbody>
          </table>
        </div>
      </div>
    </div>;
};
interface StatCardProps {
  title: string;
  value: string;
  trend: string;
  trendDirection: 'up' | 'down' | 'neutral';
  icon: React.ReactNode;
  color: string;
}
const StatCard = ({
  title,
  value,
  trend,
  trendDirection,
  icon,
  color
}: StatCardProps) => {
  return <div className="bg-white rounded-xl shadow-sm p-6 relative overflow-hidden">
      <div className={`absolute top-0 right-0 w-20 h-20 rounded-bl-full opacity-10 ${color}`} />
      <div className={`p-2 rounded-lg w-10 h-10 flex items-center justify-center mb-3 ${color}`}>
        {icon}
      </div>
      <h3 className="text-gray-500 text-sm">{title}</h3>
      <div className="flex items-end gap-2 mt-1">
        <span className="text-2xl font-bold text-gray-800">{value}</span>
        {trendDirection !== 'neutral' && <div className={`flex items-center text-sm ${trendDirection === 'up' ? 'text-emerald-600' : 'text-red-600'}`}>
            {trendDirection === 'up' ? <TrendingUpIcon size={16} /> : <TrendingDownIcon size={16} />}
            <span>{trend}</span>
          </div>}
      </div>
    </div>;
};
interface CategoryItemProps {
  name: string;
  amount: string;
  percentage: number;
  color: string;
  icon: React.ReactNode;
}
const CategoryItem = ({
  name,
  amount,
  percentage,
  color,
  icon
}: CategoryItemProps) => {
  return <div>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded ${color} text-white`}>{icon}</div>
          <span className="font-medium text-gray-700">{name}</span>
        </div>
        <span className="text-gray-900 font-medium">{amount}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div className={`${color} h-2 rounded-full`} style={{
        width: `${percentage}%`
      }}></div>
      </div>
    </div>;
};
interface TransactionRowProps {
  description: string;
  category: string;
  date: string;
  amount: string;
  type: 'income' | 'expense';
}
const TransactionRow = ({
  description,
  category,
  date,
  amount,
  type
}: TransactionRowProps) => {
  return <tr className="text-sm">
      <td className="py-3 font-medium text-gray-800">{description}</td>
      <td className="py-3">
        <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
          {category}
        </span>
      </td>
      <td className="py-3 text-gray-500">{date}</td>
      <td className={`py-3 text-right font-medium ${type === 'income' ? 'text-emerald-600' : 'text-gray-800'}`}>
        {type === 'income' ? '+' : ''}
        {amount}
      </td>
    </tr>;
};