import React, { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { Sidebar } from './components/Sidebar';
import { MobileSidebar } from './components/MobileSidebar';
import { TransactionList } from './components/TransactionList';
import { AddExpenseForm } from './components/AddExpenseForm';
import { ExpenseChart } from './components/ExpenseChart';
export function App() {
  const [activeView, setActiveView] = useState('dashboard');
  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'transactions':
        return <TransactionList />;
      case 'add':
        return <AddExpenseForm />;
      case 'charts':
        return <ExpenseChart />;
      default:
        return <Dashboard />;
    }
  };
  return <div className="flex flex-col md:flex-row w-full min-h-screen bg-gray-50">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      <MobileSidebar activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 p-4 md:p-6 overflow-y-auto">
        {renderContent()}
      </main>
    </div>;
}